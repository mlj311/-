//
//  AppDelegate.h
//  图片相似度比对
//
//  Created by 茅露军 on 2017/9/21.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

