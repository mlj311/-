//
//  GetDiff.h
//  图片相似度比对
//
//  Created by 茅露军 on 2017/9/21.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface GetDiff : NSObject
- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size;
-(UIImage*)getGrayImage:(UIImage*)sourceImage;
-(NSString *)pHashValueWithImage:(UIImage *)image;
-(NSInteger)getDifferentValueCountWithString:(NSString *)str1 andString:(NSString *)str2;
@end
