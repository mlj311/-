//
//  GetDiff.m
//  图片相似度比对
//
//  Created by 茅露军 on 2017/9/21.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import "GetDiff.h"
@interface GetDiff()

@end

@implementation GetDiff

//1.缩小图片8*8
- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size{
    UIGraphicsBeginImageContext(size);
    [img drawInRect:CGRectMake(0,0, size.width, size.height)];
    UIImage* scaledImage =UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}
//2.将图片转换成灰度图片
-(UIImage*)getGrayImage:(UIImage*)sourceImage
{
    int width = sourceImage.size.width;
    int height = sourceImage.size.height;
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceGray();
    CGContextRef context = CGBitmapContextCreate (nil,width,height,8,0,colorSpace,kCGImageAlphaNone);
    CGColorSpaceRelease(colorSpace);
    if (context == NULL) {
        return nil;
    }
    CGContextDrawImage(context,CGRectMake(0, 0, width, height), sourceImage.CGImage);
    UIImage *grayImage = [UIImage imageWithCGImage:CGBitmapContextCreateImage(context)];
    CGContextRelease(context);
    return grayImage;
}
//3.计算出图片平均灰度，然后每一点灰度与平均灰度比较，大于平均值是1，小于平均值是0
-(NSString *)pHashValueWithImage:(UIImage *)image{
    NSMutableString * pHashString = [NSMutableString string];
    CGImageRef imageRef = [image CGImage];
    unsigned long width = CGImageGetWidth(imageRef);
    unsigned long height = CGImageGetHeight(imageRef);
    CGDataProviderRef provider = CGImageGetDataProvider(imageRef);
    NSData* data = (id)CFBridgingRelease(CGDataProviderCopyData(provider));
    //    NSLog(@"data = %@",data);
    const char * heightData = (char*)data.bytes;
    int sum = 0;
    
    for (int i = 0; i < width * height; i++)
    {
        printf("%d ",heightData[i]);
        if (heightData[i] != 0)
        {
            sum += heightData[i];
        }
    }
    int avr = sum / (width * height);
    NSLog(@"%d",avr);
    for (int i = 0; i < width * height; i++)
    {
        if (heightData[i] >= avr) {
            [pHashString appendString:@"1"];
        }
        else {
            [pHashString appendString:@"0"];
        }
    }
    NSLog(@"pHashString = %@,pHashStringLength = %lu",pHashString,(unsigned long)pHashString.length);
    return pHashString;
}
//4.得到两个hashValue不同点数
-(NSInteger)getDifferentValueCountWithString:(NSString *)str1 andString:(NSString *)str2{
    NSInteger diff = 0;
    const char * s1 = [str1 UTF8String];
    const char * s2 = [str2 UTF8String];
    for (int i = 0 ; i < str1.length ;i++){
        if(s1[i] != s2[i]){
            diff++;
        }
    }
    return diff;
}
@end
