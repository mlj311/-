//
//  ViewController.m
//  图片相似度比对
//
//  Created by 茅露军 on 2017/9/21.
//  Copyright © 2017年 茅露军. All rights reserved.
//

#import "ViewController.h"
#import "GetSimilarity.h"
#import "GetDiff.h"
@interface ViewController ()
@property (nonatomic,strong) UIImage *img1;
@property (nonatomic,strong) UIImage *img2;
@property (nonatomic,strong) GetDiff *getDiff;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _img1 = [UIImage imageNamed:@"image1"];
    _img2 = [UIImage imageNamed:@"image2"];
    
    _getDiff = [[GetDiff alloc]init];
    
    UIImage * mImage1 = [_getDiff getGrayImage:[_getDiff scaleToSize:_img1 size:CGSizeMake(8, 8)]];
    UIImage * mImage2 = [_getDiff getGrayImage:[_getDiff scaleToSize:_img2 size:CGSizeMake(8, 8)]];
    NSInteger diff = [_getDiff getDifferentValueCountWithString:[_getDiff pHashValueWithImage:mImage1] andString:[_getDiff pHashValueWithImage:mImage2]];
    NSLog(@"这个Diff = %ld",(long)diff);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
